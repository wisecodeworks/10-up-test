// JavaScript Document
// as the page loads, call these scripts
jQuery(document).ready(function($) {
	$(".flexnav").flexNav({
		/* Let's control hover behavior with good ol' css instead*/
		 'hover': false,
	});



});
